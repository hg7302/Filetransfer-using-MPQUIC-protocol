package main

import (
	_ "github.com/clipperhouse/linkedlist"
	_ "github.com/clipperhouse/slice"
	_ "github.com/clipperhouse/stringer"
)
