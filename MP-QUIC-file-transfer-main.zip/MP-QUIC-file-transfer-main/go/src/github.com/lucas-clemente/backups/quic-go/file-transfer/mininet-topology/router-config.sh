#!/bin/bash

ifconfig router-eth0 10.0.0.2
ifconfig router-eth1 11.0.0.2
ifconfig router-eth2 100.0.0.2