package config

const PYTHON = "python3"

const VID_GENERATOR_PY = "../live-video-stream/stream_generator.py"

const VID_SENDER_GO = "../live-video-stream/stream_sender.go"

const VID_RECEIVER_GO = "../live-video-stream/stream_receiver.go"

const FILE_CLIENT_GO = "../file-transfer/client-multipath.go"

const FILE_SERVER_GO = "../file-transfer/server-multipath.go"